let images = ["img1.jpg", "img3.jpeg", "dog2.jpeg"]; 
let index = 0;

function next() {
    index++;
    if (index >= images.length) {
        index = 0;
    }
    document.getElementById("slide").src = images[index];
}

function prev() {
    index--;
    if (index < 0) {
        index = images.length - 1;
    }
    document.getElementById("slide").src = images[index];
}
